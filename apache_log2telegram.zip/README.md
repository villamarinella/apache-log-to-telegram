watch apache log with telegram

I have an apache webserver running and want to know if somebody has a look on my sites.

So I made a simple python2 script which send me always the last access data into my telegram account.

You will find:

apache.py
th.sh
README.md

You have to change on the top of the files your personal data.
It is quite simple and easy to understand.

Just start it with python apache.py

Stay lucky

Klaus Werner

